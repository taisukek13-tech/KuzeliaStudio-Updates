﻿$ErrorActionPreference = 'Stop'
if (-not $env:APP_ROOT -or -not $env:REPORT_ROOT) { throw 'APP_ROOT and REPORT_ROOT must be supplied' }
$appRoot = (Resolve-Path -LiteralPath $env:APP_ROOT).Path
$null = New-Item -ItemType Directory -Path $env:REPORT_ROOT -Force
$reportFile = Join-Path $env:REPORT_ROOT 'window-acceptance.json'
$exe = Join-Path $appRoot 'KuzeliaStudio.exe'
$report = [ordered]@{ passed = $false; startedAt = [DateTime]::UtcNow.ToString('o'); cases = @(); checks = [ordered]@{} }
$owned = New-Object System.Collections.ArrayList
$clock = [Diagnostics.Stopwatch]::StartNew()
$processHandles = @{}
function Assert-Result ([string]$name, [bool]$result) {
    $report.checks[$name] = $result
    if (-not $result) { throw "Failed check $name" }
}
function Wait-For ([scriptblock]$ready, [int]$milliseconds, [string]$description) {
    $limit = $clock.ElapsedMilliseconds + $milliseconds
    do {
        $value = & $ready
        if ($value) { return $value }
        Start-Sleep -Milliseconds 20
    } while ($clock.ElapsedMilliseconds -lt $limit)
    throw "Timed out waiting for $description"
}
function Start-Candidate {
    $si = New-Object System.Diagnostics.ProcessStartInfo
    $si.FileName = $exe; $si.WorkingDirectory = $appRoot; $si.UseShellExecute = $false
    $p = [Diagnostics.Process]::Start($si)
    $null = $owned.Add($p)
    $processHandles[[int]$p.Id] = $p.Handle
    return $p
}
function Read-Cpu ($p) {
    $milliseconds = [WindowCase25]::Cpu($processHandles[[int]$p.Id])
    if ($milliseconds -ge 0) { return $milliseconds }
    return $null
}
function Save-Report {
    $json = $report | ConvertTo-Json -Depth 10
    [IO.File]::WriteAllText($reportFile, $json, (New-Object Text.UTF8Encoding($false)))
}
try {
    Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes,WindowsBase
    $references = @([System.Windows.Automation.AutomationElement].Assembly.Location,
                    [System.Windows.Automation.AutomationIdentifier].Assembly.Location,
                    [System.Windows.Rect].Assembly.Location, [System.Linq.Enumerable].Assembly.Location)
    Add-Type -ReferencedAssemblies $references -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Automation;

public static class WindowCase25
{
    [DllImport("kernel32.dll")] static extern bool GetProcessTimes(IntPtr process,out long creation,out long exit,out long kernel,out long user);
    public static double Cpu(IntPtr handle) { long born,exit,kernel,user;return GetProcessTimes(handle,out born,out exit,out kernel,out user)?(kernel+user)/10000d:-1; }
    public delegate bool WindowCallback(IntPtr hwnd, IntPtr argument);
    [DllImport("user32.dll")] public static extern bool EnumWindows(WindowCallback cb, IntPtr arg);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint id);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern bool IsWindowEnabled(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hwnd, int command);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool AllowSetForegroundWindow(int pid);
    [DllImport("user32.dll")] static extern IntPtr GetAncestor(IntPtr h, uint flags);
    [DllImport("user32.dll")] static extern IntPtr WindowFromPoint(Point point);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out Rect r);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder text, int cap);
    [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
    [DllImport("user32.dll", CharSet=CharSet.Unicode, ExactSpelling=true, SetLastError=true)] static extern IntPtr SendMessageTimeoutW(IntPtr h, uint m, UIntPtr w, IntPtr l, uint f, uint t, out UIntPtr value);
    [DllImport("user32.dll", CharSet=CharSet.Unicode, ExactSpelling=true)] static extern int GetClassNameW(IntPtr hwnd,StringBuilder text,int count);
    [DllImport("kernel32.dll", ExactSpelling=true)] static extern void SetLastError(uint code);
    [DllImport("user32.dll")] static extern bool PostMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
    [StructLayout(LayoutKind.Sequential)] struct Rect { public int left, top, right, bottom; }
    [StructLayout(LayoutKind.Sequential)] struct Point { public int x, y; }
    [StructLayout(LayoutKind.Sequential)] struct ThreadInfo { public int size, flags; public IntPtr active,focus,capture,menu,move,caret; public Rect rect; }
    [DllImport("user32.dll")] static extern bool GetGUIThreadInfo(uint tid, ref ThreadInfo value);
    public static IntPtr Active(IntPtr hwnd) { uint pid; var info=new ThreadInfo(); info.size=Marshal.SizeOf(info); return GetGUIThreadInfo(GetWindowThreadProcessId(hwnd,out pid),ref info) ? info.active : IntPtr.Zero; }
    public static IntPtr[] Visible(int pid)
    {
        var all = new List<IntPtr>();
        EnumWindows(delegate(IntPtr hwnd,IntPtr unused) { uint p;GetWindowThreadProcessId(hwnd,out p);if(p==(uint)pid && IsWindowVisible(hwnd))all.Add(hwnd);return true; },IntPtr.Zero);
        return all.ToArray();
    }
    public sealed class WindowInfo
    {
        public long handle;
        public string kind,windowClass;
        public bool enabled,foreground,responsive;
        public int width,height,sendError;
        public double pingMs;
    }
    public static WindowInfo[] Inspect(int pid)
    {
        var result = new List<WindowInfo>();
        foreach(var h in Visible(pid))
        {
            var title=new StringBuilder(256); GetWindowText(h,title,title.Capacity);
            string text=title.ToString(); var cls=new StringBuilder(256); GetClassNameW(h,cls,cls.Capacity);
            var d=new WindowInfo { handle=h.ToInt64(), windowClass=cls.ToString(), enabled=IsWindowEnabled(h), foreground=GetForegroundWindow()==h };
            d.kind = text=="ホーム · Kuzelia Studio"?"home":text=="アプリを更新 · Kuzelia Studio"?"update":
                text=="Kuzelia Studio"?"splash-or-app-message":text.Contains("診断")?"diagnostics":"other";
            Rect rect;if(GetWindowRect(h,out rect)){d.width=rect.right-rect.left;d.height=rect.bottom-rect.top;}
            var time=Stopwatch.StartNew(); UIntPtr ignored; SetLastError(0);
            d.responsive=SendMessageTimeoutW(h,0,UIntPtr.Zero,IntPtr.Zero,2,500,out ignored)!=IntPtr.Zero;
            d.sendError=d.responsive?0:Marshal.GetLastWin32Error();d.pingMs=time.Elapsed.TotalMilliseconds;result.Add(d);
        }
        return result.ToArray();
    }
    public static bool SameOwner(IntPtr modal,IntPtr owner) { return GetWindow(modal,4)==owner; }
    public static bool Responds(IntPtr hwnd) { UIntPtr v; return SendMessageTimeoutW(hwnd,0,UIntPtr.Zero,IntPtr.Zero,2,500,out v)!=IntPtr.Zero; }
    public static bool Close(IntPtr hwnd) { return PostMessageW(hwnd,0x112,(IntPtr)0xf060,IntPtr.Zero); }
    public static bool Hit(IntPtr hwnd, bool screen)
    {
        Rect r; if(!GetWindowRect(hwnd,out r))return false;var p = new Point {x=r.left+(r.right-r.left)/2,y=r.top+(r.bottom-r.top)/2};
        if(screen) return GetAncestor(WindowFromPoint(p),2)==hwnd;
        var xy=new IntPtr((p.x&0xffff)|((p.y&0xffff)<<16)); UIntPtr hit;
        return SendMessageTimeoutW(hwnd,0x84,UIntPtr.Zero,xy,2,400,out hit)!=IntPtr.Zero && unchecked((long)hit.ToUInt64())>0;
    }
    public static string InvokeError;
    public static void InvokeButton(IntPtr hwnd, string name)
    {
        InvokeError=null;
        var t=new Thread(delegate() {try {
            var window=AutomationElement.FromHandle(hwnd);
            var filter=new AndCondition(new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Button),new PropertyCondition(AutomationElement.NameProperty,name));
            var item=window.FindFirst(TreeScope.Descendants,filter);
            if(item==null)throw new Exception("The requested visible button was absent");
            ((InvokePattern)item.GetCurrentPattern(InvokePattern.Pattern)).Invoke();
        }catch(Exception ex){InvokeError=ex.GetType().Name+": "+ex.Message;}});
        t.IsBackground=true;t.SetApartmentState(ApartmentState.MTA);t.Start();
    }

    // A WinEvent hook records transient foreground changes between polling samples.
    delegate void WinEvent(IntPtr hook,uint ev,IntPtr hwnd,int obj,int child,uint thread,uint time);
    [DllImport("user32.dll")] static extern IntPtr SetWinEventHook(uint min,uint max,IntPtr module,WinEvent callback,uint process,uint thread,uint flags);
    [DllImport("user32.dll")] static extern bool UnhookWinEvent(IntPtr hook);
    [StructLayout(LayoutKind.Sequential)] struct Msg { public IntPtr hwnd; public uint msg;public UIntPtr w; public IntPtr l;public uint time;public Point pt;public uint privateField; }
    [DllImport("user32.dll")] static extern bool PeekMessageW(out Msg msg,IntPtr hwnd,uint min,uint max,uint remove);
    [DllImport("user32.dll")] static extern bool TranslateMessage(ref Msg msg);
    [DllImport("user32.dll")] static extern IntPtr DispatchMessageW(ref Msg msg);
    static volatile bool stop;
    static int forbidden,modalEvents;
    static Thread watcher;
    static bool installed;
    public static bool ObserveModal(IntPtr owner,IntPtr modal)
    {
        var ready=new ManualResetEventSlim(false);stop=false;forbidden=modalEvents=0;installed=false;
        watcher=new Thread(delegate() { uint pid;GetWindowThreadProcessId(owner,out pid);
            WinEvent callback=delegate(IntPtr h,uint e,IntPtr w,int o,int c,uint t,uint x) {
                if(w==owner) Interlocked.Increment(ref forbidden);
                if(w==modal) Interlocked.Increment(ref modalEvents);
            };
            var hook=SetWinEventHook(3,3,IntPtr.Zero,callback,pid,0,0);installed=hook!=IntPtr.Zero;ready.Set();
            if(hook==IntPtr.Zero)return;
            try {while(!stop){Drain();Thread.Sleep(5);}Drain();}
            finally {UnhookWinEvent(hook);GC.KeepAlive(callback);}
        });
        watcher.IsBackground=true;watcher.Start();return ready.Wait(2000)&&installed;
    }
    static void Drain(){ Msg m;while(PeekMessageW(out m,IntPtr.Zero,0,0,1)){TranslateMessage(ref m);DispatchMessageW(ref m);} }
    public static int[] StopObservation(){stop=true;if(watcher!=null)watcher.Join(2000);return new[]{forbidden,modalEvents};}
}
'@
    Assert-Result 'KnownBinary' (Test-Path -LiteralPath $exe -PathType Leaf)
    $report.appVersion = (Get-Item -LiteralPath (Join-Path $appRoot 'KuzeliaStudio.dll')).VersionInfo.FileVersion
    $report.desktopSha256 = (Get-FileHash -LiteralPath (Join-Path $appRoot 'KuzeliaStudio.dll')).Hash.ToLowerInvariant()
    $report.coreSha256 = (Get-FileHash -LiteralPath (Join-Path $appRoot 'Kuzelia.Core.dll')).Hash.ToLowerInvariant()
    $report.launchUserProfile = 'Ordinary CI user profile'
    $before = @(Get-Process -Name KuzeliaStudio -ErrorAction SilentlyContinue | Where-Object SessionId -eq ([Diagnostics.Process]::GetCurrentProcess().SessionId))
    Assert-Result 'EmptyAppSession' ($before.Count -eq 0)
    $begin = $clock.ElapsedMilliseconds
    $primary = Start-Candidate
    $report.primaryPid = $primary.Id
    $report.windowObservations = [ordered]@{}
    function Wait-InteractiveWindow ([string]$kind, [int]$limitMs) {
        $ob = [ordered]@{attempts=0;first=$null;last=$null;transitions=@()}
        $report.windowObservations[$kind] = $ob
        $deadline = $clock.ElapsedMilliseconds + $limitMs; $previous = $null
        do {
            if ($primary.HasExited) {throw "Primary exited during $kind with code $($primary.ExitCode)"}
            if ($kind -eq 'update' -and [WindowCase25]::InvokeError) {throw [WindowCase25]::InvokeError}
            $windows = @([WindowCase25]::Inspect($primary.Id))
            $ob.attempts++
            $point = [ordered]@{elapsedMs=$clock.ElapsedMilliseconds-$begin;windows=$windows}
            if ($null -eq $ob.first) {$ob.first=$point}
            $ob.last=$point
            $state = ($windows | ForEach-Object { "$($_.handle):$($_.kind):$($_.enabled):$($_.responsive)" }) -join ','
            if ($state -ne $previous -and $ob.transitions.Count -lt 20) { $ob.transitions += $point; $previous=$state }
            foreach ($row in $windows) {
                if ($row.kind -eq $kind -and $row.enabled -and $row.responsive -and $row.width -gt 400) {
                    return [IntPtr]([long]$row.handle)
                }
            }
            Start-Sleep -Milliseconds 50
        } while($clock.ElapsedMilliseconds -lt $deadline)
        throw "Timed out waiting for an enabled responsive $kind window, see windowObservations"
    }
    $homeWindowHandle = Wait-InteractiveWindow 'home' 25000
    $report.homeReadyMs = $clock.ElapsedMilliseconds - $begin
    Assert-Result 'UsableHome' ($homeWindowHandle -ne [IntPtr]::Zero)
    function Invoke-Duplicate ([string]$label) {
        $start = $clock.ElapsedMilliseconds; $primaryCpu = Read-Cpu $primary
        $duplicate = Start-Candidate; $permission = [WindowCase25]::AllowSetForegroundWindow($duplicate.Id)
        $visible = $false
        while (-not $duplicate.HasExited -and ($clock.ElapsedMilliseconds - $start) -lt 4000) {
            if ([WindowCase25]::Visible($duplicate.Id).Length) {$visible = $true}
            Start-Sleep -Milliseconds 12
        }
        $elapsed = $clock.ElapsedMilliseconds - $start
        $code = $null; if ($duplicate.HasExited) {$code = $duplicate.ExitCode}
        $primaryAfter = Read-Cpu $primary
        $cpuDifference = if($null -ne $primaryAfter -and $null -ne $primaryCpu) {$primaryAfter-$primaryCpu} else {$null}
        $report.cases += [ordered]@{stage=$label;primaryPid=$primary.Id;duplicatePid=$duplicate.Id;secondExited=$duplicate.HasExited;
            exitCode=$code;observedThroughExitMs=$elapsed;primaryCpuDeltaMs=$cpuDifference;duplicateCpuMs=(Read-Cpu $duplicate);
            foregroundPermissionGranted=$permission;observedVisibleSecondaryWindow=$visible}
        Assert-Result ($label+'ExitedPromptly') ($duplicate.HasExited -and $code -eq 0 -and $elapsed -lt 4000)
        Assert-Result ($label+'NoSecondaryDialog') (-not $visible)
        Assert-Result ($label+'OriginalSurvives') (-not $primary.HasExited -and [WindowCase25]::IsWindow($homeWindowHandle))
    }
    Invoke-Duplicate 'ordinary'
    $null = [WindowCase25]::ShowWindowAsync($homeWindowHandle,6)
    $null = Wait-For { [WindowCase25]::IsIconic($homeWindowHandle) } 3000 'primary minimization'
    Invoke-Duplicate 'minimized'
    $restored = Wait-For { -not [WindowCase25]::IsIconic($homeWindowHandle) -and [WindowCase25]::IsWindowEnabled($homeWindowHandle) -and [WindowCase25]::Responds($homeWindowHandle) } 5000 'duplicate restoring a responsive and enabled home'
    Assert-Result 'MinimizedHomeRestored' $restored
    $null = [WindowCase25]::SetForegroundWindow($homeWindowHandle)
    [WindowCase25]::InvokeButton($homeWindowHandle,'アプリを更新')
    $modal = Wait-InteractiveWindow 'update' 10000
    $null = Wait-For { -not [WindowCase25]::IsWindowEnabled($homeWindowHandle) -and [WindowCase25]::IsWindowEnabled($modal) } 2000 'WPF modal owner disable'
    Assert-Result 'OpenedOwnedProductModal' ([WindowCase25]::SameOwner($modal,$homeWindowHandle))
    $modalStartedFront = [WindowCase25]::GetForegroundWindow() -eq $modal
    $report.modalForegroundAtStart = $modalStartedFront
    $report.modalScreenHitAtStart = [WindowCase25]::Hit($modal,$true)
    Assert-Result 'ForegroundRecorderArmed' ([WindowCase25]::ObserveModal($homeWindowHandle,$modal))
    try {
        Invoke-Duplicate 'modal'
        Start-Sleep -Milliseconds 220
        $report.modalOwnerDisabledAfterDuplicate = -not [WindowCase25]::IsWindowEnabled($homeWindowHandle)
        $report.modalVisibleEnabledAfterDuplicate = [WindowCase25]::IsWindowVisible($modal) -and [WindowCase25]::IsWindowEnabled($modal)
        $report.modalRespondsToHitTest = [WindowCase25]::Hit($modal,$false)
        $report.modalScreenHitAfterDuplicate = [WindowCase25]::Hit($modal,$true)
        $report.modalThreadActiveAfterDuplicate = [WindowCase25]::Active($homeWindowHandle) -eq $modal
        $report.modalForegroundAfterDuplicate = [WindowCase25]::GetForegroundWindow() -eq $modal
    } finally {
        $events = [WindowCase25]::StopObservation()
        $report.ownerForegroundEventsDuringModalDuplicate = $events[0]; $report.modalForegroundEventsDuringDuplicate = $events[1]
    }
    Assert-Result 'ModalPreserved' ($report.modalOwnerDisabledAfterDuplicate -and $report.modalVisibleEnabledAfterDuplicate -and $report.modalRespondsToHitTest)
    Assert-Result 'DisabledOwnerNeverActivated' ($report.ownerForegroundEventsDuringModalDuplicate -eq 0 -and ([WindowCase25]::GetForegroundWindow() -ne $homeWindowHandle) -and ([WindowCase25]::Active($homeWindowHandle) -ne $homeWindowHandle))
    Assert-Result 'InitiallyForegroundModalRetainsForeground' (-not $modalStartedFront -or ($report.modalForegroundAfterDuplicate -and $report.modalScreenHitAfterDuplicate))
    Assert-Result 'CloseModalViaCaption' ([WindowCase25]::Close($modal))
    $null = Wait-For { -not [WindowCase25]::IsWindow($modal) -and [WindowCase25]::IsWindowEnabled($homeWindowHandle) -and [WindowCase25]::Responds($homeWindowHandle) } 3500 'modal close and usable original home'
    $closeAt = $clock.ElapsedMilliseconds
    Assert-Result 'ClosePrimaryViaCaption' ([WindowCase25]::Close($homeWindowHandle))
    $null = Wait-For { $primary.HasExited } 5000 'natural main exit'
    $report.mainExitAfterCloseMs = $clock.ElapsedMilliseconds - $closeAt
    $report.primaryCpuMs = Read-Cpu $primary; $report.primaryExitCode = $primary.ExitCode
    Assert-Result 'PrimaryExitedCleanly' ($primary.ExitCode -eq 0)
    $knownNames = @('KuzeliaStudio.exe','KuzeliaSpeech.exe','ffmpeg.exe','ffprobe.exe','llama-server.exe','yt-dlp.exe','deno.exe','createdump.exe')
    $knownPids = @{}; foreach ($p in $owned) { $knownPids[[int]$p.Id] = $true }
    $residuals = New-Object System.Collections.ArrayList
    $startObservation = $clock.ElapsedMilliseconds; $snapshots = 0
    do {
        $processes = @(Get-CimInstance Win32_Process -Property ProcessId,ParentProcessId,Name,ExecutablePath)
        do {
            $previous = $knownPids.Count
            foreach ($p in $processes) {
                $underRoot = $knownNames -contains $p.Name -and $p.ExecutablePath -and $p.ExecutablePath.StartsWith($appRoot.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)
                if ($underRoot -or $knownPids.ContainsKey([int]$p.ParentProcessId)) { $knownPids[[int]$p.ProcessId] = $true }
            }
        } while($previous -ne $knownPids.Count)
        foreach ($p in $processes) {
            if ($knownPids.ContainsKey([int]$p.ProcessId)) { $null=$residuals.Add([ordered]@{pid=[int]$p.ProcessId;name=$p.Name;sincePrimaryExitMs=$clock.ElapsedMilliseconds-$startObservation}) }
        }
        $snapshots++; Start-Sleep -Milliseconds 150
    } while ($clock.ElapsedMilliseconds-$startObservation -lt 3000)
    $report.postCloseObservationMs=$clock.ElapsedMilliseconds-$startObservation; $report.postCloseSnapshots=$snapshots
    $report.observedResidualProcesses=@($residuals.ToArray())
    Assert-Result 'NoObservedProductProcessesAfterClose' ($residuals.Count -eq 0)
    $report.passed = $true
} catch {
    $report.error = $_.Exception.Message
    throw
} finally {
    $report.finishedAt = [DateTime]::UtcNow.ToString('o')
    Save-Report
    # Cleanup runs only after the evidence above was written. Never stop unrelated PIDs.
    foreach ($p in $owned) {
        try { if (-not $p.HasExited) { $p.Kill(); $null=$p.WaitForExit(3000) } } catch {}
        $p.Dispose()
    }
}
