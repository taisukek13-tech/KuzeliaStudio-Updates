﻿# CI-only. Runs in an isolated standard-user runner session. No reports from a user's PC.
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$root = Join-Path $env:RUNNER_TEMP ('exit-support-' + [guid]::NewGuid().ToString('N'))
$null = New-Item -ItemType Directory -Force -Path $root, $env:REPORT_ROOT
$zip = Join-Path $PSScriptRoot 'Kuzelia-ExitCheck-Windows-x64.zip'
$tools = Join-Path $root 'unpacked'
Expand-Archive -LiteralPath $zip -DestinationPath $tools
$exe = Join-Path $tools 'KuzeliaExitCheck.exe'
$hash = (Get-FileHash $exe -Algorithm SHA256).Hash.ToLowerInvariant()
if ($hash -ne '5fc525c4fb4d6f51a48fa2d75a57ca9cf43ff0784904d34022cc1aa2bad4bfdc') { throw 'Unexpected tool bytes' }
if ((Get-ChildItem $tools -File).Count -ne 2) { throw 'Unexpected package inventory' }
$fixture = Join-Path $root 'fixture'
$null = New-Item -ItemType Directory $fixture
@'
using System;
using System.Diagnostics;
using System.Threading;
public class Fixture
{
    public static void Main(string[] args)
    {
        if (args.Length > 1) {
            Process.Start(new ProcessStartInfo(args[1], args[2]) { UseShellExecute=false });
        }
        Thread.Sleep(int.Parse(args[0]) * 1000);
    }
}
'@ | Set-Content (Join-Path $fixture 'fixture.cs') -Encoding Ascii
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$fakeRoot = Join-Path $fixture 'KuzeliaStudio.exe'
$child = Join-Path $fixture 'DiagnosticFixtureChild.exe'
& $compiler /nologo /target:winexe /platform:x64 "/out:$fakeRoot" (Join-Path $fixture 'fixture.cs')
if ($LASTEXITCODE -ne 0) { throw 'Fixture compilation failed' }
Copy-Item $fakeRoot $child
function Begin-Diagnostic([string]$case) {
    $folder = Join-Path $root $case
    $null = New-Item -ItemType Directory $folder
    $path = Join-Path $folder 'KuzeliaExitCheck.exe'
    Copy-Item $exe $path
    $p = New-Object Diagnostics.ProcessStartInfo
    $p.FileName=$path; $p.WorkingDirectory=$folder
    $p.UseShellExecute=$false; $p.RedirectStandardInput=$true; $p.RedirectStandardOutput=$true
    $instance = [Diagnostics.Process]::Start($p)
    return [pscustomobject]@{ Process=$instance; Folder=$folder; Case=$case }
}
function Complete-Diagnostic($item, [int]$timeout) {
    if (!$item.Process.WaitForExit($timeout*1000)) { throw "$($item.Case) timeout" }
    if ($item.Process.ExitCode -ne 0) { throw "$($item.Case) exit code $($item.Process.ExitCode)" }
    $file = @(Get-ChildItem $item.Folder -Filter '*.txt')
    if ($file.Count -ne 1) { throw "$($item.Case) missing result" }
    $body = [IO.File]::ReadAllText($file[0].FullName, [Text.Encoding]::UTF8)
    if ($body -notmatch '基準から (\d+(?:\.\d+)?) 秒' -or [double]$Matches[1] -lt 40.0) { throw 'Incomplete post-mark window' }
    if ($body -notmatch '物理メモリ合計 [\d.]+ GiB' -or $body -notmatch '(?m)^\d\d:\d\d:\d\d\.\d+ \| [^|]+ \| [\d.]+ \| [\d.]+ \| [\d.]+ \| [\d.]+ \| [\d.]+/[\d.]+ \| [\d.]+ \| [\d.]+ \|') { throw 'Windows CPU / physical disk / RAM counters unavailable' }
    if ($body -match '([A-Za-z]:\\|\\\\[^\\\s]+\\|https?://|BEGIN PRIVATE KEY)' -or $body.Contains($root)) { throw 'Unexpected path in text' }
    $lines = @($body -split '\r?\n')
    $summary = [ordered]@{
        postWindow=($lines | Where-Object {$_ -like '測定終了*'})
        initial=($lines | Where-Object {$_ -like '測定開始時の本体*'})
        ever=($lines | Where-Object {$_ -like '測定全体の本体*'})
        final=($lines | Where-Object {$_ -like '最終時点の本体*'})
        mark=($lines | Where-Object {$_ -like '×操作後のEnter*' -or $_ -like '状態記録のEnter*' -or $_ -like '入力期限*'})
        kind=($lines | Where-Object {$_ -like '測定の種類*'})
        toolCpu=($lines | Where-Object {$_ -like '物理メモリ合計*'})
        valuesValid=$true; noPathsInReport=$true; reportBytes=$file[0].Length
    }
    return [pscustomobject]@{ body=$body; summary=$summary }
}
if (Get-Process KuzeliaStudio -ErrorAction SilentlyContinue) { throw 'Separate CI session required' }
$summaries=[ordered]@{}
Write-Host 'Measuring the bounded no-launch/no-input path.'
$item=Begin-Diagnostic 'absent'
# EOF is not an Enter mark, so the normal inactivity timeout must apply.
$item.Process.StandardInput.Close()
$already=Begin-Diagnostic 'already-closed'
$reboot=Begin-Diagnostic 'post-reboot'
$already.Process.StandardInput.WriteLine(); $already.Process.StandardInput.Flush()
$reboot.Process.StandardInput.WriteLine('2'); $reboot.Process.StandardInput.Flush()
$r=Complete-Diagnostic $already 70
if ($r.summary.kind -notlike '*すでに閉じた後*' -or $r.summary.mark -notlike '状態記録のEnter*' -or $r.summary.ever -notlike '*観測なし') {throw 'Incorrect already-closed evidence label'}
$summaries.alreadyClosed=$r.summary
$r=Complete-Diagnostic $reboot 30
if ($r.summary.kind -notlike '*PC再起動後*' -or $r.summary.mark -notlike '状態記録のEnter*' -or $r.summary.ever -notlike '*観測なし') {throw 'Incorrect no-app comparison label'}
$summaries.postReboot=$r.summary
$result=Complete-Diagnostic $item 160
if ($result.summary.mark -notlike '入力期限*' -or $result.summary.ever -notlike '*観測なし' -or $result.summary.final -notlike '*判定不可') {throw 'No-launch/timeout behavior incorrect'}
$summaries.absent=$result.summary
Write-Host 'Starting the released app and exercising its main window close button.'
$item=Begin-Diagnostic 'release'
Start-Sleep -Seconds 6
$program = Get-Item (Join-Path $env:APP_ROOT 'KuzeliaStudio.exe')
$pi = New-Object Diagnostics.ProcessStartInfo
$pi.FileName=$program.FullName; $pi.WorkingDirectory=$program.DirectoryName; $pi.UseShellExecute=$false
$released = [Diagnostics.Process]::Start($pi)
$ready=$false
foreach ($i in 1..60) {
    $released.Refresh()
    if ($released.HasExited) { throw 'Released app exited before close' }
    if ($released.MainWindowHandle -ne [IntPtr]::Zero) { $ready=$true; break }
    Start-Sleep -Milliseconds 500
}
if(!$ready){throw 'Released main window not found'}
Start-Sleep -Seconds 4
if(!$released.CloseMainWindow()){throw 'Normal close failed'}
$item.Process.StandardInput.WriteLine('1'); $item.Process.StandardInput.Flush()
$result=Complete-Diagnostic $item 80
if($result.summary.initial -notlike '*見つからず' -or $result.summary.ever -notlike '*観測あり' -or $result.summary.mark -notlike '×操作後のEnter*' -or $result.summary.kind -notlike '*起動・×操作の前後' -or $result.body -notmatch [regex]::Escape("KuzeliaStudio.exe(PID $($released.Id))")) {throw 'Released app lifetime tracking incorrect'}
$summaries.release=$result.summary
if(!$released.HasExited){throw 'Released app remained and interferes with independent fixture'}
Write-Host 'Testing an existing parent, a lingering child and a separate process with the same image name.'
$unrelated = [Diagnostics.Process]::Start($child,'59')
$family = [Diagnostics.Process]::Start($fakeRoot,('16 "' + $child + '" 58'))
Start-Sleep -Seconds 2
$item=Begin-Diagnostic 'orphan'
Start-Sleep -Seconds 4
$item.Process.StandardInput.WriteLine('1'); $item.Process.StandardInput.Flush()
$result=Complete-Diagnostic $item 65
if ($result.summary.initial -notlike '*起動中' -or $result.summary.final -notlike '*DiagnosticFixtureChild.exe*' -or $result.summary.final -like '*KuzeliaStudio.exe*' -or $result.summary.final -like "*PID $($unrelated.Id))*") {throw 'Surviving child attribution incorrect'}
if ($result.body -notmatch [regex]::Escape("KuzeliaStudio.exe(PID $($family.Id))") -or $result.summary.mark -notlike '×操作後のEnter*'){throw 'Existing parent or manual mark missing'}
$summaries.orphan=$result.summary
Write-Host 'Testing a parent that is still present at final sampling.'
$family = [Diagnostics.Process]::Start($fakeRoot,'52')
$item=Begin-Diagnostic 'lingering'
Start-Sleep -Seconds 4
$item.Process.StandardInput.WriteLine('1'); $item.Process.StandardInput.Flush()
$result=Complete-Diagnostic $item 65
if($result.summary.initial -notlike '*起動中' -or $result.summary.final -notlike "*KuzeliaStudio.exe(PID $($family.Id))*"){throw 'Lingering root detection incorrect'}
$summaries.lingering=$result.summary
[ordered]@{windowsVersion=[Environment]::OSVersion.VersionString; toolSha256=$hash; packageSha256=(Get-FileHash $zip -Algorithm SHA256).Hash.ToLowerInvariant(); allPassed=$true; cases=$summaries} | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $env:REPORT_ROOT 'exit-support-check.json') -Encoding UTF8
Write-Host 'All six Windows support tool cases passed.'
